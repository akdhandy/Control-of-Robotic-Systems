clc;
clear all;
%output variable
y0 = [10; 2; 40; 2; 60; 2]
tspan = 0:0.01:5000;%timespan

[t1,y1] = ode45(@nonlinear,tspan,y0); %use ode45 function

plot(t1,y1)%plot
grid on


function dydt = nonlinear(t,x)

M = 1000;
m1	=100;	
m2	= 100;	
l1 = 20;	
l2 = 10;	
g =	9.81;
dydt =zeros(6,1);
A=	[0	1 0 0 0	0,	
	0 0 -m1*g/M 0 -m2*g/M 0,	
	0 0 0 1 0 0,	
	0 0	(-g*(m1+M))/(M*l1)	0	(-m2*g)/(M*l1)	0,
	0 0 0 0 0 1,	
	0 0	(-m1*g)/(M*l2)	0	(-g*(m2+M))/(M*l2)	0];
B=	[0	1/M 0	1/(M*l1)	0	1/(M*l2)]';	
C=	[1	0 0 0 0	0,	
	0 1 0 0 0 0,	
	0 0 1 0 0 0,	
	0 0 0 1 0 0,	
	0 0 0 0 1 0,	
	0	0	0	0 0 1] ;		

% LQR Controller 
Q = 100*(C'*C);
R = 0.001;
[K,~,~] = lqr(A,B,Q,R);
F=-K*x;


D=(M+(m1*((sind(x(3)))^2))+(m2*((sind(x(5)))^2)));
x_d = ((F - g*((m1*sind(x(3))*cosd(x(3)))- (m2*sind(x(5))*cosd(x(5))))...
- (m1*l1*sind(x(3))*((x(4))^2))- (m2*l2*sind(x(5))*((x(6))^2)))/D);
theta1_double_dot = (((x_d * cosd(x(3)))-g*(sind(x(3))))/l1);
theta2_double_dot = (((x_d * cosd(x(5)))-g*(sind(x(5))))/l2); 

dydt (1) = x(2); 
dydt (2)= x_d;
dydt (3)= x(4);
dydt (4)= theta1_double_dot;
dydt (5)= x(6); 
dydt (6)= theta2_double_dot;
end