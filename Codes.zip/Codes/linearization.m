clc;
clear all;
syms F M m1 m2 l1 l2 x1 x2 x3 x4 x5 x6 g real

%Representing the non-linear state-space equations
D=(M+(m1*((sin(x3))^2))+(m2*((sin(x5))^2)));
x_d = ((F - g*((m1*sin(x3)*cos(x3))- (m2*sin(x5)*cos(x5)))...
- (m1*l1*sin(x3)*(x4^2))- (m2*l2*sin(x5)*(x6^2)))/D);
theta1_double_dot = (((x_d * cos(x3))-g*(sin(x3)))/l1);
theta2_double_dot = (((x_d * cos(x5))-g*(sin(x5)))/l2);
f1 = x2;
f2 = x_d;
f3 = x4;
f4 = theta1_double_dot;
f5 = x2;
f6 = theta2_double_dot;

%Find Jacobian of Matrix A
jacob_A = [ diff(f1,x1) diff(f1,x2) diff(f1,x3) diff(f1,x4) diff(f1,x5) diff(f1,x6);
diff(f2,x1) diff(f2,x2) diff(f2,x3) diff(f2,x4) diff(f2,x5) diff(f2,x6);
diff(f3,x1) diff(f3,x2) diff(f3,x3) diff(f3,x4) diff(f3,x5) diff(f3,x6);
diff(f4,x1) diff(f4,x2) diff(f4,x3) diff(f4,x4) diff(f4,x5) diff(f4,x6);
diff(f5,x1) diff(f5,x2) diff(f5,x3) diff(f5,x4) diff(f5,x5) diff(f5,x6);
diff(f6,x1) diff(f6,x2) diff(f6,x3) diff(f6,x4) diff(f6,x5) diff(f6,x6) ];

%Find Jacobian of Matrix B w.r.t Input i.e. F
jacob_B = [ diff(f1,F); diff(f2,F); diff(f3,F); diff(f4,F); diff(f5,F); diff(f6,F)];

%Substituting values around equilibrium point for A
jacobian_A =subs(jacob_A, [x1 x2 x3 x4 x5 x6],[ 0 0 0 0 0 0]);
%Substituting values around equilibrium point for B
jacobian_B = subs(jacob_B, [x1 x2 x3 x4 x5 x6],[ 0 0 0 0 0 0]);

