clc;
clear all;
syms m1 m2 M l1 l2 g
A= [0 1 0 0 0 0,
0	0 -m1*g/M 0 -m2*g/M 0,
0	0 0 1 0 0,
0	0 (-g*(m1+M))/(M*l1) 0 (-m2*g)/(M*l1) 0,
0	0 0 0 0 1,
0	0 (-m1*g)/(M*l2) 0 (-g*(m2+M))/(M*l2) 0];

B= [0 1/M 0 1/(M*l1) 0 1/(M*l2)]';

C = [B A*B (A*A)*B (A*A*A)*B (A*A*A*A)*B (A*A*A*A*A)*B];
det(C);
rankC = rank(C);

% ml = m2			
c_1 = subs(C,m1,m2);			
rankC_m = rank(c_1);
if rank(c_1) == rank(C)
    fprintf('case 01: ml = m2 -- Controllable System\n\n');
else
    fprintf('case 01: ml = m2 -- UnControllable System\n\n')
end

% 11 = 12
c_2 = subs(C,l1,l2);
rankC_1 = rank(c_2); 
if rank(c_2) == rank(C)	
fprintf('Case 2: 11 = 12 -- Controllable System\n\n');
else
fprintf('Case 2: 11 = 12 -- Uncontrollable System\n\n')
end	

% ml = M
c_3 = subs(C,m1,M);

rankC_M = rank(c_3); 
if rank(c_3) == rank(C)
fprintf('case 3: ml = M -- Controlable system\n\n' );
else
fprintf('case 3: ml = M -- Uncontrolable system\n\n');
end

%case 04: m2 = M
c_4 = subs(C,m2,M);
rankC_M2 = rank(c_4); 
if rank(c_4) == rank(C)
fprintf('case 4: m2 = M -- Controlable system\n\n');
else
fprintf('case 4: m2 = M -- Uncontrolable system\n\n' );
end

