clc;
clear all;
M = 1000;
m1	=100;	
m2	= 100;	
l1 = 20;	
l2 = 10;	
g =	9.81;

A=	[0	1 0 0 0	0,	
	0 0 -m1*g/M 0 -m2*g/M 0,	
	0 0 0 1 0 0,	
	0 0	(-g*(m1+M))/(M*l1)	0	(-m2*g)/(M*l1)	0,
	0 0 0 0 0 1,	
	0 0	(-m1*g)/(M*l2)	0	(-g*(m2+M))/(M*l2)	0];
B=	[0	1/M 0	1/(M*l1)	0	1/(M*l2)]';	
C=	[1	0 0 0 0	0,	
	0 1 0 0 0 0,	
	0 0 1 0 0 0,	
	0 0 0 1 0 0,	
	0 0 0 0 1 0,	
	0	0	0	0 0 1] ;	
D=	[0	0	0	0	0	0]';	

% LQR Controller 
Q = C'*C;
R = 0.001;
K = lqr(A,B,Q,R);
plotting(A,B,C,D,K);

%For different Value of Q.
Q= 10*[10 3 2 5 2 3,
    3 100 5 2 2 3,
    2 4 5 2 2 4,
    5 7 6 5 6 6,
    2 5 2 5 100 6,
    3 7 3 5 4 10];
Q=(Q+Q')/2;
K = lqr(A,B,Q,R); 
plotting(A,B,C,D,K);


% Lyapunovs indirect method
vals = eig(A-B*K); 
if (vals<0)
     fprintf('All Eigen Values in the left half plane and System is stable')
else
    fprintf('System Unstable')
end   


function plotting(A,B,C,D,K)
[y,t]=stepSim(A,B,C,D,K);

% Closed Loop System Plot
figure;
subplot(2,1,1)
[AX] = plotyy(t,y(:,1),t,y(:,2),'plot');
set(get(AX(1),'Ylabel'),'String','Cart Position (m)') 
set(get(AX(2),'Ylabel'),'String','Theta 1 (radians)') 
title('Step Response with LQR Control for Theta 1')
subplot(2,1,2)

[AX] = plotyy(t,y(:,1),t,y(:,3),'plot'); 
set(get(AX(1),'Ylabel'),'String','Cart Position (m)') 
set(get(AX(2),'Ylabel'),'String','Theta 2 (radians)') 
title('Step Response with LQR Control for Theta 2')
end

function [y,t] = stepSim(A,B,C,D,K)
Ac = A-B*K;

%Closed loop System
stateSpaceModelClosedLoop = ss(Ac,B,C,D);
t = 0:0.01:100;
r = 0.2*ones(size(t));
[y,t]=lsim(stateSpaceModelClosedLoop,r,t);
end
