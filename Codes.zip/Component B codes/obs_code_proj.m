syms M m1 m2 g l1 l2
A=[0 1 0 0 0 0;0 0 -m1*g/M 0 -m2*g/M 0;0 0 0 1 0 0;0 0 -(M*g-m1*g)/M*l1 0 -m2*g/M*l1 0;0 0 0 0 0 1;0 0 -m1*g/M*l2 0 -(M*g-m2*g)/M*l2 0];
D=transpose(A);
C=[1 ;0 ;0 ;0 ;0 ;0 ];%for x(t)
%C=[0 0;0 0;1 0;0 0;0 1;0 0];%for theta1(t),theta2(t)
%C=[1 0;0 0;0 0;0 0;0 1;0 0];%for x(t),theta2(t)
%C=[1 0 0;0 0 0;0 1 0;0 0 0;0 0 1;0 0 0];%for x(t),theta1(t),theta2(t)
K=[C D*C D^2*C D^3*C D^4*C D^5*C];
E=rank(K);
disp(K)
disp(E)