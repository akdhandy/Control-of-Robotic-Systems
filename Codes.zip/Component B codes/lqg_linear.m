syms m1 m2 l1 l2 g M a


m1 = 100;
m2 = 100;
M = 1000;
l1 = 20;
l2 = 10;
g = 9.8;

a = 1;

%Initial Conditions
x0 =[6;0.35;0.12;0;0;0;0;0;0;0;0;0];


%Matrices
A=  [0 1 0 0 0 0; 
    0 0 -(m1*g)/M 0 -(m2*g)/M 0;
    0 0 0 1 0 0;
    0 0 -((M+m1)*g)/(M*l1) 0 -(m2*g)/(M*l1) 0;
    0 0 0 0 0 1;
    0 0 -(m1*g)/(M*l2) 0 -(g*(M+m2))/(M*l2) 0];

Q=[10 0 0 0 0 0;
   0 70 0 0 0 0;
   0 0 100 0 0 0;
   0 0 0 80 0 0;
   0 0 0 0 90 0;
   0 0 0 0 0 100];

B=[0; 1/M; 0; 1/(M*l1); 0; 1/(M*l2)];
C=eye(6);
%C = [1,0,0,0,0,0];
D = 0;
R = 0.0001;

K =lqr(A,B,Q,R);%LQR
vd=0.3*eye(6);%Noise
vn=1;%Noise
KF=lqr(A',C',vd,vn);%LQR with Kalman Filter
KF=KF';


if a == 1
    sys = ss([(A-B*K) B*K; zeros(size(A)) (A-KF*C)], [B;zeros(size(B))],[C zeros(size(C))], [0]);
    initial(sys,x0)%No step function
end
if a == 2
    sys = ss([(A-B*K) B*K; zeros(size(A)) (A-KF*C)], [B;zeros(size(B))],[C zeros(size(C))], [0]);
    step(sys)%With step function
end
    
grid on
