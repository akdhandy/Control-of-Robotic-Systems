syms m1 m2 l1 l2 g M

m1 = 100;
m2 = 100;
M = 1000;
l1 = 20;
l2 = 10;
g = 9.8;

poles=[-1;-2;-3;-4;-5;-6];

%Initial Conditions
x0=[0,0,10,0,30,0,0,0,0,0,0,0];

%Matrices
A=[0 1 0 0 0 0; 
    0 0 -(m1*g)/M 0 -(m2*g)/M 0;
    0 0 0 1 0 0;
    0 0 -((M+m1)*g)/(M*l1) 0 -(m2*g)/(M*l1) 0;
    0 0 0 0 0 1;
    0 0 -(m1*g)/(M*l2) 0 -(g*(M+m2))/(M*l2) 0];
B=[0; 1/M; 0; 1/(M*l1); 0; 1/(M*l2)];
Q=[10 0 0 0 0 0;
   0 700 0 0 0 0;
   0 0 1000 0 0 0;
   0 0 0 800 0 0;
   0 0 0 0 900 0;
   0 0 0 0 0 1000];
R=0.01;
%  C1, C3 and C4 are observable
C1 = [1 0 0 0 0 0];  %Corresponding to x(t)
C3 = [1 0 0 0 0 0; 0 0 0 0 1 0]; %corresponding to x(t) and theata2(t)
C4 = [1 0 0 0 0 0; 0 0 1 0 0 0; 0 0 0 0 1 0]; %corresponding to x(t), theta1(t) and theata2(t)
D = 0;

K=lqr(A,B,Q,R);
L1 = place(A',C1',poles)'
L3 = place(A',C3',poles)'
L4 = place(A',C4',poles)'

Aq1 = [(A-B*K) B*K;
        zeros(size(A)) (A-L1*C1)];
Bq = [B;zeros(size(B))];
Cq1 = [C1 zeros(size(C1))];

Aq3 = [(A-B*K) B*K;
        zeros(size(A)) (A-L3*C3)];
Cq3 = [C3 zeros(size(C3))];

Aq4 = [(A-B*K) B*K;
        zeros(size(A)) (A-L4*C4)];
Cq4 = [C4 zeros(size(C4))];

sys1 = ss(Aq1, Bq, Cq1, D);%x(t)
figure 
initial(sys1,x0)
figure 
step(sys1)
sys3 = ss(Aq3, Bq, Cq3, D);%x(t) and theta1(t) 
figure 
initial(sys3,x0)
figure 
step(sys3)
sys4 = ss(Aq4, Bq, Cq4, D);%x(t),theta1(t) and theta2(t)
figure 
initial(sys4,x0)
figure 
step(sys4)
    
grid on



