clc;
clear all;
%output variable
y0 = [10;0.50;0.7;0;0;0;0;0;0;0;0;0];
tspan = 400:0.01:500;%timespan

[t1,y1] = ode45(@nonlinear_lqg,tspan,y0); %use ode45 function

plot(t1,y1)%plot
grid on

function dydt=nonlinear_lqg(t,x)
%syms m1 m2 l1 l2 g M F U

m1 = 100;
m2 = 100;
M = 1000;
l1 = 20;
l2 = 10;
g = 9.8;


%Matrices
A=[0 1 0 0 0 0;
    0 0 -(m1*g)/M 0 -(m2*g)/M 0;
    0 0 0 1 0 0;
    0 0 -((M+m1)*g)/(M*l1) 0 -(m2*g)/(M*l1) 0;
    0 0 0 0 0 1;
    0 0 -(m1*g)/(M*l2) 0 -(g*(M+m2))/(M*l2) 0];
Q=[10 0 0 0 0 0;
   0 700 0 0 0 0;
   0 0 1000 0 0 0;
   0 0 0 800 0 0;
   0 0 0 0 900 0;
   0 0 0 0 0 1000];
B=[0; 1/M; 0; 1/(M*l1); 0; 1/(M*l2)];
C = [1 0 0 0 0 0];
D = 0;
R = 0.0001;

K =lqr(A,B,Q,R);
vd=0.3*eye(6);%Noise
vn=1;%Noise
KF=lqr(A',C',vd,vn);%lqg similar to lqr with addition of noises(Kalman Filter)
KF=KF';
F=-K*x(1:6);


error_dot=(A-KF*C)*x(7:12);
dydt=zeros(12,1);
D=(M+(m1*((sind(x(3)))^2))+(m2*((sind(x(5)))^2)));
x_d = ((F - g*((m1*sind(x(3))*cosd(x(3)))- (m2*sind(x(5))*cosd(x(5))))...
- (m1*l1*sind(x(3))*((x(4))^2))- (m2*l2*sind(x(5))*((x(6))^2)))/D);
theta1_double_dot = (((x_d * cosd(x(3)))-g*(sind(x(3))))/l1);
theta2_double_dot = (((x_d * cosd(x(5)))-g*(sind(x(5))))/l2);
dydt (1) = x(2);
dydt (2)= x_d;
dydt (3)= x(4);
dydt (4)= theta1_double_dot;
dydt (5)= x(6);
dydt (6)= theta2_double_dot;
dydt (7)= x(2)-x(10);
dydt (8)= dydt(2)-error_dot(2);
dydt (9)= x(4)-x(11);
dydt (10)= dydt(4)-error_dot(4);
dydt (11)= x(6)-x(12);
dydt (12)= dydt(6)-error_dot(6);
end